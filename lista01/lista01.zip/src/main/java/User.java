public class User {

    public String user;

    public String password;
}
